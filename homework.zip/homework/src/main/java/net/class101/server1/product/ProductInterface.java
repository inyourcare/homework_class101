package net.class101.server1.product;

public interface ProductInterface {
}
