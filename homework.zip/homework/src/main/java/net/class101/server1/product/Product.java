package net.class101.server1.product;

public class Product implements ProductInterface {

    int productNumber;
    String productName;
    int productPrice;
    int productStockCount;
    String kind;

    public Product(int productNumber, String productName, int productPrice, int productStockCount) {
        this.productNumber = productNumber;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productStockCount = productStockCount;
    }

    public int getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(int productNumber) {
        this.productNumber = productNumber;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductStockCount() {
        return productStockCount;
    }

    public void setProductStockCount(int productStockCount) {
        this.productStockCount = productStockCount;
    }
}
