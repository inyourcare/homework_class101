package net.class101.server1.code;

public class ProjectCode {

    public enum ProductKind {
        Class("C"), Kit("K");

        String code;

        ProductKind(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }
    }
}
